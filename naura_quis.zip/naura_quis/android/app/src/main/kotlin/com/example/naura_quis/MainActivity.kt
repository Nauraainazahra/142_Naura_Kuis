package com.example.naura_quis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
